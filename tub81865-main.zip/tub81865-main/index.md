---
title: Home
nav_order: 1
---

# 👋 Welcome

Hi! I’m **Your Name**, a [short description — e.g. researcher, map designer, etc.].

Use the links on the left (or top, depending on theme) to explore:

- [About Me](about.md)
- [Projects](projects.md)
- [Contact](contact.md)
