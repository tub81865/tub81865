---
title: About Me
nav_order: 2
---

# About Me

I’m a geographer and educator passionate about mapping, cities, and design.

- **Current role:** Professor of Urban Spatial Design in Japan  
- **Interests:** Web mapping, spatial analysis, and creative geography 
