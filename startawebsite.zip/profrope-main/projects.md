---
title: Projects
nav_order: 3
---

# Projects

Here are some of my favorite works:

| Year | Project | Description |
|------|----------|--------------|
| 2024 | Tokyo Mapping Studio | A collection of urban spatial stories |
| 2023 | Cities in Motion | An interactive Leaflet map series |
